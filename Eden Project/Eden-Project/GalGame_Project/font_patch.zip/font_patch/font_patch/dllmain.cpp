﻿// dllmain.cpp : 定义 DLL 应用程序的入口点。
#include "framework.h"

HFONT WINAPI HookCreateFontIndirectW(LOGFONTW* lplf)
{
    LOGFONTW lf;
    memcpy(&lf, lplf, sizeof(LOGFONTW));
    wcscpy(lf.lfFaceName, L"SimHei");
    lf.lfCharSet = GB2312_CHARSET;
    return CreateFontIndirectW(&lf);
}

HFONT WINAPI HookCreateFontIndirectA(LOGFONTA* lplf)
{
    LOGFONTA lf;
    memcpy(&lf, lplf, sizeof(LOGFONTA));
    strcpy(lf.lfFaceName, "SimHei");
    lf.lfCharSet = GB2312_CHARSET;
    return CreateFontIndirectA(&lf);
}

void IATHook()
{
    if (!IATPatch("Gdi32.dll", GetProcAddress(GetModuleHandleW(L"Gdi32.dll"), "CreateFontIndirectW"), (PROC)HookCreateFontIndirectW))
    {
        MessageBoxW(0, L"CreateFontIndirectW Hook Error。", L"IATHook Error", 0);
        return;
    }
    if (!IATPatch("Gdi32.dll", GetProcAddress(GetModuleHandleW(L"Gdi32.dll"), "CreateFontIndirectA"), (PROC)HookCreateFontIndirectA))
    {
        MessageBoxW(0, L"CreateFontIndirectA Hook Error。", L"IATHook Error", 0);
        return;
    }
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        IATHook();
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

