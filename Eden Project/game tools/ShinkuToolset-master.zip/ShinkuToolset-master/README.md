# ShinkuToolset
translation toolset for FAVORITE's games (FVP Engine)

## FVPCompress
Pack bmp image to FVP's texture.

## FVPDeasm
Disassemble *.hcb bytecode.

## FVPDecompiler
Decompile *.hcb bytecode into c-like pseudocode.

## FVPTextExtract
Extract text from *.hcb bytecode(for translation project).

## UniversalPatch
Patch sample, you should implement some API functions before compiling (It's very easy to implement).