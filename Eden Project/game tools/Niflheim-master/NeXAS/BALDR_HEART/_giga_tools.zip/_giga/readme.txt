for unpack: drag pac file to pac_unpack.exe
for repack: drag folder to pac_pack.exe

About *.bin or *.dat:
https://github.com/AyamiKaze/Niflheim/tree/master/NeXAS/BALDR_HEART
you can download hole project and find it.